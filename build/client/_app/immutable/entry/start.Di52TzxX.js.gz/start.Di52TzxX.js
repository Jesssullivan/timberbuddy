import{a as t}from"../chunks/entry.CyP2UbcE.js";export{t as start};
