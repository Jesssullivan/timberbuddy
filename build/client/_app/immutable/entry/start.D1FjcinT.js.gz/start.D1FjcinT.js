import{a as t}from"../chunks/entry.B4ji62ci.js";export{t as start};
