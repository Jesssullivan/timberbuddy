import{a as t}from"../chunks/entry.Bl8pTr5r.js";export{t as start};
